package com.example.demo.mahend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MahendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MahendApplication.class, args);
	}

}
